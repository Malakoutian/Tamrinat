// import Buttonme from "./component/Button"
// import MyCard from "./component/Card"
import List from "./component/List"
import './App.css'

const App=()=>{
    return (
      <>
        <div> <h3>تمرین جلسه ۱۰ ساخت دکمه و کارت و لیست</h3> </div>
        {/* <div>
          <Buttonme icon="./src/assets/react.svg" mylink="Home1"> Click </Buttonme>
        </div>
        <MyCard title="CardTitle" tumbnail="./src/assets/vite.svg" action={<Buttonme icon="./src/assets/react.svg" mylink="https://www.google.com"> More... </Buttonme>} >This is first my card</MyCard> */}
        <List numberOfitems={10}/>
     
      </>
    )
}

export default App
