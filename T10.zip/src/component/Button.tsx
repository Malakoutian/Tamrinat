

const Buttonme=({mylink , icon , children} : {mylink: string, icon?: string , children?:React.ReactNode }) =>{
   
    return (
     <>
        <div  className="mybtn">
            <a href={mylink}>
                <div>
                     {icon ==="" ? "" : <img  src ={icon} alt='myicon'/>}
                </div>
                <div>
                    <p>{children === "" ? "newbutton" : children }</p>
                </div>
            </a>
        </div>
     </>
    )
}

export default Buttonme

// Button ==> Pas ->href, text , icon 
// Card   ==> Title ,Tumbnail, Content = Children , Action = getComponent
// List   ==> 10 Card with random Data