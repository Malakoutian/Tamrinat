import type React from "react"

const MyCard = ({title , tumbnail , action , children} : {title : string , tumbnail?: string , action?: React.ReactNode , children?: React.ReactNode})=>{

    return(
        <>
            <div className="myCard">
                <br />
                <img src={tumbnail} alt="" /> <br />
                <p><h3>{title}</h3></p>
                {children }
                {action}
            </div>
        </>
    )
}

export default MyCard

// Card   ==> Title ,Tumbnail, Content = Children , Action = getComponent