import MyCard from "./Card"
import Buttonme from "./Button"

// const reName=({myitem} : {myitem:Number})=>{
//     return "Title"+myitem.toString()
// }

const List = ({numberOfitems} : {numberOfitems?:number})=>{
    const items= new Array(numberOfitems).fill(0).map((_,i)=>i+1)

    return(
        <>
            <ul>
                {
                    items.map(item=>{
                        return (
                        <li key={item}> 
                            <MyCard title={`Title ${item}`} tumbnail="./src/assets/vite.svg" action={<Buttonme icon="./src/assets/react.svg" mylink="https://www.google.com"> {`Item ${item}`} </Buttonme>}>
                            </MyCard>
                        </li>)
                    })
                }
            </ul>
        </>
    )
}

export default List
